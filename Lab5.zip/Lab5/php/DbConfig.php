<?php
$local=0; //0 para la nube
if ($local==1){
    $server="localhost";
    $user="root";
    $pass="";
    $basededatos="quiz";
}
else{
    $server="localhost";
    $user="id14915151_jorge2000";
    $pass="Salchipapa69!";
    $basededatos="id14915151_jorge";
}
?>
